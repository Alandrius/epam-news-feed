# I have used the following technologies:
1) BEM metodology

2) Stylus SCC preprocessor

3) Flexboxes and media-queries

4) ENB to build the project

5) I haven't used any special JS libraries and have used only native JavaScript


# To build the project please do the following
1) Clone this repository

2) Go to the project's directory

3) Perform "npm install"

4) Perform "npm start". You should see something like this: Server started at http://0.0.0.0:8080

5) Open http://127.0.0.1:8080/desktop.bundles/index/index.html in the browser