# Contributors

The list of contributors is available at https://github.com/bem/bem-components/graphs/contributors. You may also get it with `git log --pretty=format:"%an <%ae>" | sort -u`.
