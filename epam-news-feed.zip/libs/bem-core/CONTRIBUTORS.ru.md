# Контрибьюторам

Список контрибьютеров данного проекта доступен по ссылке https://github.com/bem/bem-core/graphs/contributors. Вы так же можете получить его с помощью команды `git log --pretty=format:"%an <%ae>" | sort -u`.
